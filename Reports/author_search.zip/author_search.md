

```python
import os
os.getcwd()
from __future__ import division
# The %... is an iPython thing, and is not part of the Python language.
# In this case we're just telling the plotting library to draw things on
# the notebook, instead of on a separate window.
%matplotlib inline
# See all the "as ..." contructs? They're just aliasing the package names.
# That way we can call methods like plt.plot() instead of matplotlib.pyplot.plot().
import numpy as np
import scipy as sp
import matplotlib as mpl
import matplotlib.cm as cm
import matplotlib.pyplot as plt
import pandas as pd
import time
pd.set_option('display.width', 500)
pd.set_option('display.max_columns', 100)
pd.set_option('display.notebook_repr_html', True)
import seaborn as sns
sns.set_style("whitegrid")
#sns.set_context("poster")
```


```python
# -*- coding: utf-8 -*-
"""
Created on Sat May 21 11:46:30 2016

@author: Raunak Mundada
"""
import scholarly_edit
import mysql_setup

def extractAuthorProfiles(author_list):
    #Author_Detail = {}
    
    
    for i in author_list:
        Author_Detail = []
        Pub_Detail = []
        apub_detail = []
        temp = 'NULL'
        print (i)
        a_obj = next(scholarly_edit.search_author(i)).fill()
        #print (a_obj)
        '''

        if hasattr(a_obj,'email') == False:
            setattr(a_obj,'email') = temp
        if hasattr(a_obj,'citedby') == False:
            setattr(a_obj,'citedby') = temp
        if hasattr(a_obj,'affiliation') == False:
            setattr(a_obj,'affiliation') = temp
        '''
        
        Author_Detail.append([str(a_obj.id),str(a_obj.name),str(a_obj.affiliation), str(a_obj.email),
                              str(",".join(a_obj.interests)),a_obj.citedby,a_obj.hIndex,a_obj.i_10_index,a_obj.hIndex_recent,
                              a_obj.i_10_index_recent])
        
        print ("Add Author Details to SQL")
        mysql_setup.updateAuthor(Author_Detail)      
        apub_detail = extractPublish(a_obj)
        #apub_detail.extend([a_obj.id,a_obj.name])
        Pub_Detail.append(apub_detail)
        print ("Add Publishing Details to SQL")
        mysql_setup.updatePublish(Pub_Detail)
        
        
    return Author_Detail,Pub_Detail
    
def extractPublish(a_obj):
    Pub_list = []
    journal_list = []
    # Assign NA to non-existent columns
    
    for i in a_obj.publications:
        # Assign NA to non-existent columns
        pub = i.fill()
        temp = 'NULL'
        if pub.bib.has_key("volume") == False:
            pub.bib['volume'] = temp
        if pub.bib.has_key("publisher") == False:
            pub.bib['publisher'] = temp
        if pub.bib.has_key("author") == False:
            pub.bib['author'] = temp
        if pub.bib.has_key("url") == False:
            pub.bib['url'] = temp
        if pub.bib.has_key("journal") == False:
            pub.bib['journal'] = temp
            
        if pub.bib.has_key("abstract") == True:
            if not isinstance(pub.bib['abstract'],unicode):
                #print type(pub.bib['abstract'])
                pub.bib['abstract2'] = pub.bib['abstract'].text
            elif isinstance(pub.bib['abstract'],unicode):
                pub.bib['abstract2'] = pub.bib['abstract']
        else:
            pub.bib['abstract2'] = temp
            
            
        if pub.bib.has_key("title") == False:
            pub.bib['title'] = temp
        if pub.bib.has_key("year") == False:
            pub.bib['year'] = -99
        if hasattr(pub,'citedby') == False:
            setattr(pub,'citedby',-99)
        '''
        if pub.bib.has_key['journal'] == True:
          journalTitle = pub.bib['journal']
          search_query = scholarly_edit.search_journal(journalTitle)
          journal_item = next(search_query)
          journal_list.append([journal_item.pub['journal_id'],journal_item.pub['title'],journal_item.pub['h5_index'],
            journal_item.pub['h5_median'],journal_item.pub['url']])
        '''
        Pub_list.append([pub.id_citations,pub.bib['title'], pub.bib['author'],
                       pub.bib['publisher'],pub.bib['journal'],pub.bib['abstract2'], pub.bib['volume'], pub.bib['year'], 
                        pub.citedby ,pub.bib['url'],pub.id_citations.partition(':')[0]])
    return Pub_list

if __name__ == '__main__':
    mysql_setup.mysqlConn()
    author_list = ['Yann LeCun']
    scrape_Data = extractAuthorProfiles(author_list)
    
'''
author_list = ['Alex Leff','Lars Kasper','Florent Haiss','Cheng Soon Ong','Patrick E Brown',
                  'Geoffrey Hinton','Michael I. Jordan','Jonathan Hays','Daphne Koller','Sayan Mukherjee',
                  'Michael Collins','Monnie McGee','Tony Ng','Michael Hahsler','Kalyanmoy Deb','David Lopez Mateos',
                  'vapnik','Corinna Cortes','Jason Weston','Yann LeCun']
'''
```

    Creating table Author: already exists.
    Creating table Publishing_Detail: already exists.
    Yann LeCun
    Add Author Details to SQL
    Error: 1062 (23000): Duplicate entry 'WLN3QrAAAAAJ' for key 'PRIMARY'
    Add Publishing Details to SQL
    




    "\nauthor_list = ['Alex Leff','Lars Kasper','Florent Haiss','Cheng Soon Ong','Patrick E Brown',\n                  'Geoffrey Hinton','Michael I. Jordan','Jonathan Hays','Daphne Koller','Sayan Mukherjee',\n                  'Michael Collins','Monnie McGee','Tony Ng','Michael Hahsler','Kalyanmoy Deb','David Lopez Mateos',\n                  'vapnik','Corinna Cortes','Jason Weston','Yann LeCun']\n"




```python
import mysql_setup
query_list,field_names = mysql_setup.query_with_fetchmany("SELECT * FROM Author")
Author = mysql_setup.make_frame(query_list,field_names)
```


```python
query_list,field_names = mysql_setup.query_with_fetchmany("SELECT * FROM Publishing_Detail")
Publishing_Detail = mysql_setup.make_frame(query_list,field_names)
```


```python
Author
```




<div>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Author_Id</th>
      <th>Author_Name</th>
      <th>Author_Affiliation</th>
      <th>Author_Email</th>
      <th>Author_Interests</th>
      <th>Author_Cited_By</th>
      <th>Author_hIndex</th>
      <th>Author_i10Index</th>
      <th>Author_hIndex_recent</th>
      <th>Author_i10Index_recent</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1DS8DjgAAAAJ</td>
      <td>Jonathan Hays</td>
      <td>Queen Mary University of London</td>
      <td>@qmul.ac.uk</td>
      <td>Particle Physics,Higgs bosons,Machine learning...</td>
      <td>60944</td>
      <td>115</td>
      <td>572</td>
      <td>108</td>
      <td>520</td>
    </tr>
    <tr>
      <th>1</th>
      <td>5Iqe53IAAAAJ</td>
      <td>Daphne Koller</td>
      <td>Professor of Computer Science, Stanford Univer...</td>
      <td>@cs.stanford.edu</td>
      <td>machine learning,computational biology,compute...</td>
      <td>50410</td>
      <td>112</td>
      <td>269</td>
      <td>77</td>
      <td>238</td>
    </tr>
    <tr>
      <th>2</th>
      <td>6yx_xmcAAAAJ</td>
      <td>Kay H. Brodersen</td>
      <td>Google, Inc. / ETH Zurich</td>
      <td>@inf.ethz.ch</td>
      <td>Bayesian inference,Machine learning,Computatio...</td>
      <td>837</td>
      <td>14</td>
      <td>17</td>
      <td>14</td>
      <td>17</td>
    </tr>
    <tr>
      <th>3</th>
      <td>967CPlsAAAAJ</td>
      <td>Hon Keung Tony Ng</td>
      <td>Department of Statistical Science, Southern Me...</td>
      <td>@mail.smu.edu</td>
      <td>Statistics,Reliability,Biostatistics</td>
      <td>1610</td>
      <td>20</td>
      <td>39</td>
      <td>18</td>
      <td>33</td>
    </tr>
    <tr>
      <th>4</th>
      <td>DNMBVxcAAAAJ</td>
      <td>Patrick E Brown</td>
      <td>University of Toronto</td>
      <td>@utoronto.ca</td>
      <td>Statistics</td>
      <td>2250</td>
      <td>23</td>
      <td>51</td>
      <td>17</td>
      <td>30</td>
    </tr>
    <tr>
      <th>5</th>
      <td>DxoenfgAAAAJ</td>
      <td>Michael Collins</td>
      <td>Professor of Computer Science, Columbia Univer...</td>
      <td>@cs.columbia.edu</td>
      <td>Computational Linguistics,Natural Language Pro...</td>
      <td>17039</td>
      <td>47</td>
      <td>70</td>
      <td>40</td>
      <td>66</td>
    </tr>
    <tr>
      <th>6</th>
      <td>fOZJofkAAAAJ</td>
      <td>Monnie McGee</td>
      <td>Southern Methodist University</td>
      <td>@smu.edu</td>
      <td>Data Analysis,Flow Cytometry Data,Gene Express...</td>
      <td>1273</td>
      <td>15</td>
      <td>19</td>
      <td>12</td>
      <td>14</td>
    </tr>
    <tr>
      <th>7</th>
      <td>JicYPdAAAAAJ</td>
      <td>Geoffrey Hinton</td>
      <td>Emeritus Professor of Computer Science, Univer...</td>
      <td>@cs.toronto.edu</td>
      <td>machine learning,neural networks,artificial in...</td>
      <td>133698</td>
      <td>120</td>
      <td>288</td>
      <td>87</td>
      <td>205</td>
    </tr>
    <tr>
      <th>8</th>
      <td>lMkTx0EAAAAJ</td>
      <td>Jason Weston</td>
      <td>Facebook</td>
      <td>@fb.com</td>
      <td>Artificial Intelligence,Machine Learning,Bioin...</td>
      <td>28073</td>
      <td>63</td>
      <td>125</td>
      <td>51</td>
      <td>116</td>
    </tr>
    <tr>
      <th>9</th>
      <td>ofMZr0IAAAAJ</td>
      <td>Cheng Soon Ong</td>
      <td>Data61, Canberra</td>
      <td>@anu.edu.au</td>
      <td>Machine Learning,Bioinformatics,Computational ...</td>
      <td>2539</td>
      <td>21</td>
      <td>30</td>
      <td>18</td>
      <td>26</td>
    </tr>
    <tr>
      <th>10</th>
      <td>P6krKIkAAAAJ</td>
      <td>David Lopez Mateos</td>
      <td>Research Associate, Harvard University</td>
      <td>@physics.harvard.edu</td>
      <td>Data science,high energy physics,machine learning</td>
      <td>56022</td>
      <td>101</td>
      <td>291</td>
      <td>97</td>
      <td>279</td>
    </tr>
    <tr>
      <th>11</th>
      <td>paTAXiIAAAAJ</td>
      <td>Kalyanmoy Deb</td>
      <td>Professor of Electrical and Computer Engineeri...</td>
      <td>@egr.msu.edu</td>
      <td>Optimization,Evolutionary Computation,Multi-ob...</td>
      <td>88035</td>
      <td>97</td>
      <td>351</td>
      <td>70</td>
      <td>272</td>
    </tr>
    <tr>
      <th>12</th>
      <td>PL1XGecAAAAJ</td>
      <td>Lars Kasper</td>
      <td>MR-Technology Group &amp; Translational Neuromodel...</td>
      <td>@biomed.ee.ethz.ch</td>
      <td>Matched-filter fMRI,Magnetic Field Monitoring,...</td>
      <td>468</td>
      <td>8</td>
      <td>6</td>
      <td>8</td>
      <td>6</td>
    </tr>
    <tr>
      <th>13</th>
      <td>p_gkFfUAAAAJ</td>
      <td>Florent Haiss</td>
      <td>RWTH Aachen University</td>
      <td>@rwth-aachen.de</td>
      <td>Neuroscience</td>
      <td>1537</td>
      <td>15</td>
      <td>17</td>
      <td>15</td>
      <td>17</td>
    </tr>
    <tr>
      <th>14</th>
      <td>R94cBVgAAAAJ</td>
      <td>Sayan Mukherjee</td>
      <td>Duke University, MIT</td>
      <td>@stat.duke.edu</td>
      <td>machine learning,computational biology,stochas...</td>
      <td>22477</td>
      <td>39</td>
      <td>79</td>
      <td>33</td>
      <td>68</td>
    </tr>
    <tr>
      <th>15</th>
      <td>uUg1IykAAAAJ</td>
      <td>Michael Hahsler</td>
      <td>Southern Methodist University</td>
      <td>@hahsler.net</td>
      <td>Data mining,visualization,recommender systems</td>
      <td>1262</td>
      <td>19</td>
      <td>36</td>
      <td>13</td>
      <td>20</td>
    </tr>
    <tr>
      <th>16</th>
      <td>uwZaCzQAAAAJ</td>
      <td>Alex Leff</td>
      <td>Institute of Cognitive Neuroscience and Instit...</td>
      <td>@ucl.ac.uk</td>
      <td>Language,Reading,Aphasia,Alexia,fMRI</td>
      <td>4094</td>
      <td>32</td>
      <td>58</td>
      <td>28</td>
      <td>50</td>
    </tr>
    <tr>
      <th>17</th>
      <td>U_IVY50AAAAJ</td>
      <td>Corinna Cortes</td>
      <td>Google Research, NY</td>
      <td>@google.com</td>
      <td>Machine Learning,Datamining</td>
      <td>28008</td>
      <td>39</td>
      <td>70</td>
      <td>31</td>
      <td>57</td>
    </tr>
    <tr>
      <th>18</th>
      <td>vtegaJgAAAAJ</td>
      <td>vapnik</td>
      <td>Professor of Columbia, Fellow of NEC Labs Amer...</td>
      <td>@nec-labs.com</td>
      <td>machine learning,statistics,computer science</td>
      <td>168020</td>
      <td>108</td>
      <td>372</td>
      <td>73</td>
      <td>278</td>
    </tr>
    <tr>
      <th>19</th>
      <td>WLN3QrAAAAAJ</td>
      <td>Yann LeCun</td>
      <td>Director of AI Research at Facebook &amp; Silver P...</td>
      <td>@cs.nyu.edu</td>
      <td>AI,machine learning,computer vision,robotics,i...</td>
      <td>35315</td>
      <td>81</td>
      <td>202</td>
      <td>64</td>
      <td>155</td>
    </tr>
    <tr>
      <th>20</th>
      <td>yxUduqMAAAAJ</td>
      <td>Michael I. Jordan</td>
      <td>Professor of EECS and Professor of Statistics,...</td>
      <td>@cs.berkeley.edu</td>
      <td>machine learning,statistics,computational biol...</td>
      <td>99956</td>
      <td>129</td>
      <td>397</td>
      <td>88</td>
      <td>334</td>
    </tr>
    <tr>
      <th>21</th>
      <td>ZpG_cJwAAAAJ</td>
      <td>Robert Tibshirani</td>
      <td>Professor of Health Research and Policy, and S...</td>
      <td>@stanford.edu</td>
      <td>Statistics,Applied Statistics,Statistical lear...</td>
      <td>222620</td>
      <td>130</td>
      <td>336</td>
      <td>94</td>
      <td>283</td>
    </tr>
  </tbody>
</table>
</div>




```python
Publishing_Detail
```




<div>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Pub_Id</th>
      <th>Pub_Title</th>
      <th>Pub_Authors</th>
      <th>Pub_Publisher</th>
      <th>Pub_Journal</th>
      <th>Pub_Abstract</th>
      <th>Pub_Volume</th>
      <th>Pub_Year</th>
      <th>Pub_Citedby</th>
      <th>Pub_URL</th>
      <th>Author_Id</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>1DS8DjgAAAAJ:-38epGy1wY0C</td>
      <td>Quasi-elastic scattering of the proton drip li...</td>
      <td>S Chatrchyan,V Khachatryan,AM Sirunyan,A Tumas...</td>
      <td>NULL</td>
      <td>NULL</td>
      <td>NULL</td>
      <td>48</td>
      <td>1970</td>
      <td>-99</td>
      <td>http://scholar.google.com/scholar?cluster=1371...</td>
      <td>1DS8DjgAAAAJ</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1DS8DjgAAAAJ:-6RzNnnwWf8C</td>
      <td>Measurement of the muon charge asymmetry in p ...</td>
      <td>Victor Mukhamedovich Abazov,B Abbott,BS Achary...</td>
      <td>American Physical Society</td>
      <td>Physical Review D</td>
      <td>We present a measurement of the muon charge as...</td>
      <td>88</td>
      <td>2013</td>
      <td>26</td>
      <td>http://journals.aps.org/prd/abstract/10.1103/P...</td>
      <td>1DS8DjgAAAAJ</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1DS8DjgAAAAJ:-7ulzOJl1JYC</td>
      <td>Measurement of color flow in t t¯ events from ...</td>
      <td>Victor Mukhamedovich Abazov,B Abbott,BS Achary...</td>
      <td>American Physical Society</td>
      <td>Physical Review D</td>
      <td>We present the first measurement of the color ...</td>
      <td>83</td>
      <td>2011</td>
      <td>39</td>
      <td>http://journals.aps.org/prd/abstract/10.1103/P...</td>
      <td>1DS8DjgAAAAJ</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1DS8DjgAAAAJ:-DxkuPiZhfEC</td>
      <td>Evidence for the Decay B s 0→ D s (*) D s (*) ...</td>
      <td>VM Abazov,B Abbott,M Abolins,BS Acharya,M Adam...</td>
      <td>American Physical Society</td>
      <td>Physical review letters</td>
      <td>We search for the semi-inclusive process B s 0...</td>
      <td>102</td>
      <td>2009</td>
      <td>27</td>
      <td>http://journals.aps.org/prl/abstract/10.1103/P...</td>
      <td>1DS8DjgAAAAJ</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1DS8DjgAAAAJ:-f6ydRqryjwC</td>
      <td>Measurement of the Shape of the Boson-Transver...</td>
      <td>VM Abazov,B Abbott,M Abolins,BS Acharya,M Adam...</td>
      <td>American Physical Society</td>
      <td>Physical review letters</td>
      <td>We present a measurement of the shape of the Z...</td>
      <td>100</td>
      <td>2008</td>
      <td>201</td>
      <td>http://journals.aps.org/prl/abstract/10.1103/P...</td>
      <td>1DS8DjgAAAAJ</td>
    </tr>
    <tr>
      <th>5</th>
      <td>1DS8DjgAAAAJ:-FonjvnnhkoC</td>
      <td>Search for the Standard Model Higgs boson prod...</td>
      <td>Georges Aad,Brad Abbott,Jalal Abdallah,O Abdin...</td>
      <td>Springer Berlin Heidelberg</td>
      <td>The European Physical Journal C</td>
      <td>A search for the Standard Model Higgs boson pr...</td>
      <td>75</td>
      <td>2015</td>
      <td>175</td>
      <td>http://link.springer.com/article/10.1140/epjc/...</td>
      <td>1DS8DjgAAAAJ</td>
    </tr>
    <tr>
      <th>6</th>
      <td>1DS8DjgAAAAJ:-jrNzM816MMC</td>
      <td>Measurement of the Ratio of the 3-jet to 2-jet...</td>
      <td>Serguei Chatrchyan,V Khachatryan,AM Sirunyan,A...</td>
      <td>North-Holland</td>
      <td>Physics Letters B</td>
      <td>NULL</td>
      <td>702</td>
      <td>2011</td>
      <td>40</td>
      <td>http://www.sciencedirect.com/science/article/p...</td>
      <td>1DS8DjgAAAAJ</td>
    </tr>
    <tr>
      <th>7</th>
      <td>1DS8DjgAAAAJ:-mN3Mh-tlDkC</td>
      <td>Search for first-generation scalar leptoquarks...</td>
      <td>VM Abazov,B Abbott,M Abolins,BS Acharya,M Adam...</td>
      <td>American Physical Society</td>
      <td>Physical Review D</td>
      <td>We report on a search for pair production of f...</td>
      <td>71</td>
      <td>2005</td>
      <td>40</td>
      <td>http://journals.aps.org/prd/abstract/10.1103/P...</td>
      <td>1DS8DjgAAAAJ</td>
    </tr>
    <tr>
      <th>8</th>
      <td>1DS8DjgAAAAJ:-nhnvRiOwuoC</td>
      <td>Search for the standard model Higgs boson in t...</td>
      <td>VM Abazov,B Abbott,M Abolins,BS Acharya,M Adam...</td>
      <td>American Physical Society</td>
      <td>Physical review letters</td>
      <td>We present a search for the standard model Hig...</td>
      <td>102</td>
      <td>2009</td>
      <td>35</td>
      <td>http://journals.aps.org/prl/abstract/10.1103/P...</td>
      <td>1DS8DjgAAAAJ</td>
    </tr>
    <tr>
      <th>9</th>
      <td>1DS8DjgAAAAJ:-uzm3Y7AvW0C</td>
      <td>Search for physics beyond the standard model i...</td>
      <td>Serguei Chatrchyan,V Khachatryan,Albert M Siru...</td>
      <td>Springer Berlin Heidelberg</td>
      <td>The European Physical Journal C</td>
      <td>A search for physics beyond the standard model...</td>
      <td>73</td>
      <td>2013</td>
      <td>52</td>
      <td>http://link.springer.com/10.1140/epjc/s10052-0...</td>
      <td>1DS8DjgAAAAJ</td>
    </tr>
    <tr>
      <th>10</th>
      <td>1DS8DjgAAAAJ:-vzq6BoH5oUC</td>
      <td>Search for the standard model Higgs boson prod...</td>
      <td>S Chatrchyan,V Khachatryan,A Sirunyan,A Tumasy...</td>
      <td>NULL</td>
      <td>Journal of High Energy Physics</td>
      <td>A search for the Higgs boson produced in assoc...</td>
      <td>11</td>
      <td>1970</td>
      <td>-99</td>
      <td>https://www.infona.pl/resource/bwmeta1.element...</td>
      <td>1DS8DjgAAAAJ</td>
    </tr>
    <tr>
      <th>11</th>
      <td>1DS8DjgAAAAJ:-yGd096yOn8C</td>
      <td>Search for the lightest scalar top quark in ev...</td>
      <td>VM Abazov,B Abbott,M Abolins,BS Acharya,M Adam...</td>
      <td>North-Holland</td>
      <td>Physics Letters B</td>
      <td>We report results of a search for the pair pro...</td>
      <td>659</td>
      <td>2008</td>
      <td>77</td>
      <td>http://www.sciencedirect.com/science/article/p...</td>
      <td>1DS8DjgAAAAJ</td>
    </tr>
    <tr>
      <th>12</th>
      <td>1DS8DjgAAAAJ:-_dYPAW6P2MC</td>
      <td>Measurement of the semileptonic charge asymmet...</td>
      <td>Victor Mukhamedovich Abazov,B Abbott,BS Achary...</td>
      <td>American Physical Society</td>
      <td>Physical Review D</td>
      <td>We present a measurement of the semileptonic m...</td>
      <td>86</td>
      <td>2012</td>
      <td>83</td>
      <td>http://journals.aps.org/prd/abstract/10.1103/P...</td>
      <td>1DS8DjgAAAAJ</td>
    </tr>
    <tr>
      <th>13</th>
      <td>1DS8DjgAAAAJ:08ZZubdj9fEC</td>
      <td>Search for leptonic decays of W′ bosons in pp ...</td>
      <td>Serguei Chatrchyan,Vardan Khachatryan,Albert M...</td>
      <td>Springer-Verlag</td>
      <td>Journal of High Energy Physics</td>
      <td>A bstract A search for a new heavy gauge boson...</td>
      <td>2012</td>
      <td>2012</td>
      <td>95</td>
      <td>http://link.springer.com/article/10.1007/JHEP0...</td>
      <td>1DS8DjgAAAAJ</td>
    </tr>
    <tr>
      <th>14</th>
      <td>1DS8DjgAAAAJ:0aBXIfxlw9sC</td>
      <td>Measurement of the production cross section fo...</td>
      <td>Serguei Chatrchyan,V Khachatryan,AM Sirunyan,A...</td>
      <td>Springer Berlin Heidelberg</td>
      <td>Journal of High Energy Physics</td>
      <td>A bstract A measurement of the Zγ→ννγ cross se...</td>
      <td>2013</td>
      <td>2013</td>
      <td>14</td>
      <td>http://link.springer.com/article/10.1007/JHEP1...</td>
      <td>1DS8DjgAAAAJ</td>
    </tr>
    <tr>
      <th>15</th>
      <td>1DS8DjgAAAAJ:0CzhzZyukY4C</td>
      <td>Identification and energy calibration of hadro...</td>
      <td>Georges Aad,B Abbott,J Abdallah,S Abdel Khalek...</td>
      <td>Springer Berlin Heidelberg</td>
      <td>The European Physical Journal C</td>
      <td>This paper describes the trigger and offline r...</td>
      <td>75</td>
      <td>2015</td>
      <td>67</td>
      <td>http://link.springer.com/article/10.1140/epjc/...</td>
      <td>1DS8DjgAAAAJ</td>
    </tr>
    <tr>
      <th>16</th>
      <td>1DS8DjgAAAAJ:0EnyYjriUFMC</td>
      <td>Transverse-momentum and pseudorapidity distrib...</td>
      <td>Vardan Khachatryan,Albert M Sirunyan,Armen Tum...</td>
      <td>American Physical Society</td>
      <td>Physical Review Letters</td>
      <td>Charged-hadron transverse-momentum and pseudor...</td>
      <td>105</td>
      <td>2010</td>
      <td>453</td>
      <td>http://journals.aps.org/prl/abstract/10.1103/P...</td>
      <td>1DS8DjgAAAAJ</td>
    </tr>
    <tr>
      <th>17</th>
      <td>1DS8DjgAAAAJ:0izLItjtcgwC</td>
      <td>Measurement of the production cross section an...</td>
      <td>VM Abazov,B Abbott,M Abolins,BS Acharya,M Adam...</td>
      <td>North-Holland</td>
      <td>Physics Letters B</td>
      <td>We present a measurement of the top quark pair...</td>
      <td>679</td>
      <td>2009</td>
      <td>57</td>
      <td>http://www.sciencedirect.com/science/article/p...</td>
      <td>1DS8DjgAAAAJ</td>
    </tr>
    <tr>
      <th>18</th>
      <td>1DS8DjgAAAAJ:0KyAp5RtaNEC</td>
      <td>Measurement of masses in the\ mathrm {t}\ over...</td>
      <td>Serguei Chatrchyan,V Khachatryan,AM Sirunyan,A...</td>
      <td>Springer Berlin Heidelberg</td>
      <td>The European Physical Journal C</td>
      <td>A simultaneous measurement of the top-quark, W...</td>
      <td>73</td>
      <td>2013</td>
      <td>79</td>
      <td>http://link.springer.com/article/10.1140/epjc/...</td>
      <td>1DS8DjgAAAAJ</td>
    </tr>
    <tr>
      <th>19</th>
      <td>1DS8DjgAAAAJ:0N-VGjzr574C</td>
      <td>Study of the underlying event at forward rapid...</td>
      <td>Serguei Chatrchyan,V Khachatryan,AM Sirunyan,A...</td>
      <td>Springer Berlin Heidelberg</td>
      <td>Journal of High Energy Physics</td>
      <td>A bstract The underlying event activity in pro...</td>
      <td>2013</td>
      <td>2013</td>
      <td>67</td>
      <td>http://link.springer.com/article/10.1007/JHEP0...</td>
      <td>1DS8DjgAAAAJ</td>
    </tr>
    <tr>
      <th>20</th>
      <td>1DS8DjgAAAAJ:0ngZmJvimKcC</td>
      <td>Measurements of four-lepton production in pp c...</td>
      <td>Georges Aad,A Clark,D Cinca,A Milic,AS Thompso...</td>
      <td>Elsevier</td>
      <td>Physics letters B</td>
      <td>The four-lepton (4 ℓ , ℓ=e,μ ) production cros...</td>
      <td>NULL</td>
      <td>2016</td>
      <td>3</td>
      <td>http://repo.scoap3.org/record/13114</td>
      <td>1DS8DjgAAAAJ</td>
    </tr>
    <tr>
      <th>21</th>
      <td>1DS8DjgAAAAJ:17ZO-CJnx_8C</td>
      <td>Combination of CDF and D0 Results on the Top-Q...</td>
      <td>VM Abazov,PN Ratoff,M Begel,YA Yatsunenko,S Ja...</td>
      <td>NULL</td>
      <td>NULL</td>
      <td>NULL</td>
      <td>NULL</td>
      <td>2005</td>
      <td>-99</td>
      <td>http://scholar.google.com/scholar?cluster=1020...</td>
      <td>1DS8DjgAAAAJ</td>
    </tr>
    <tr>
      <th>22</th>
      <td>1DS8DjgAAAAJ:1DsIQWDZLl8C</td>
      <td>Measurement of the Λ b 0 lifetime using semile...</td>
      <td>VM Abazov,B Abbott,M Abolins,BS Acharya,M Adam...</td>
      <td>American Physical Society</td>
      <td>Physical review letters</td>
      <td>We report a measurement of the Λ b 0 lifetime ...</td>
      <td>99</td>
      <td>2007</td>
      <td>35</td>
      <td>http://journals.aps.org/prl/abstract/10.1103/P...</td>
      <td>1DS8DjgAAAAJ</td>
    </tr>
    <tr>
      <th>23</th>
      <td>1DS8DjgAAAAJ:1EqfMoDn7-AC</td>
      <td>Measurement of Jet Multiplicity Distributions ...</td>
      <td>S Chatrchyan,V Khachatryan,AM Sirunyan,A Tumas...</td>
      <td>Springer-Verlag</td>
      <td>NULL</td>
      <td>The normalised differential top quark-antiquar...</td>
      <td>NULL</td>
      <td>1970</td>
      <td>-99</td>
      <td>http://dspace.mit.edu/handle/1721.1/91191</td>
      <td>1DS8DjgAAAAJ</td>
    </tr>
    <tr>
      <th>24</th>
      <td>1DS8DjgAAAAJ:1lhNe0rCu4AC</td>
      <td>Search for new physics with long-lived particl...</td>
      <td>Serguei Chatrchyan,Vardan Khachatryan,Albert M...</td>
      <td>Springer-Verlag</td>
      <td>Journal of High Energy Physics</td>
      <td>A bstract A search is performed for long-lived...</td>
      <td>2012</td>
      <td>2012</td>
      <td>86</td>
      <td>http://link.springer.com/article/10.1007/jhep1...</td>
      <td>1DS8DjgAAAAJ</td>
    </tr>
    <tr>
      <th>25</th>
      <td>1DS8DjgAAAAJ:1paMEeroeoQC</td>
      <td>Measurement of the B [subscript s][superscript...</td>
      <td>S Chatrchyan,V Khachatryan,A Sirunyan,A Tumasy...</td>
      <td>American Physical Society</td>
      <td>NULL</td>
      <td>The B [subscript s][superscript 0] differentia...</td>
      <td>NULL</td>
      <td>1970</td>
      <td>-99</td>
      <td>http://dspace.mit.edu/handle/1721.1/71192</td>
      <td>1DS8DjgAAAAJ</td>
    </tr>
    <tr>
      <th>26</th>
      <td>1DS8DjgAAAAJ:1qzjygNMrQYC</td>
      <td>Combined Tevatron upper limit on g g→ H→ W+ W−...</td>
      <td>Terhi Aaltonen,Victor Mukhamedovich Abazov,B A...</td>
      <td>American Physical Society</td>
      <td>Physical Review D</td>
      <td>We combine results from searches by the CDF an...</td>
      <td>82</td>
      <td>2010</td>
      <td>52</td>
      <td>http://journals.aps.org/prd/abstract/10.1103/P...</td>
      <td>1DS8DjgAAAAJ</td>
    </tr>
    <tr>
      <th>27</th>
      <td>1DS8DjgAAAAJ:1r-w4gtu6w8C</td>
      <td>Determination of spin and parity of the Higgs ...</td>
      <td>Georges Aad,B Abbott,J Abdallah,O Abdinov,R Ab...</td>
      <td>Springer Berlin Heidelberg</td>
      <td>The European Physical Journal C</td>
      <td>NULL</td>
      <td>75</td>
      <td>2015</td>
      <td>227</td>
      <td>NULL</td>
      <td>1DS8DjgAAAAJ</td>
    </tr>
    <tr>
      <th>28</th>
      <td>1DS8DjgAAAAJ:1sJd4Hv_s6UC</td>
      <td>Azimuthal anisotropy of charged particles at h...</td>
      <td>Serguei Chatrchyan,Vardan Khachatryan,Albert M...</td>
      <td>American Physical Society</td>
      <td>Physical review letters</td>
      <td>The azimuthal anisotropy of charged particles ...</td>
      <td>109</td>
      <td>2012</td>
      <td>123</td>
      <td>http://journals.aps.org/prl/abstract/10.1103/P...</td>
      <td>1DS8DjgAAAAJ</td>
    </tr>
    <tr>
      <th>29</th>
      <td>1DS8DjgAAAAJ:1taIhTC69MYC</td>
      <td>Search for the Higgs Boson in H→ W W (*) Decay...</td>
      <td>VM Abazov,B Abbott,M Abolins,BS Acharya,M Adam...</td>
      <td>American Physical Society</td>
      <td>Physical review letters</td>
      <td>We present a search for the standard model Hig...</td>
      <td>96</td>
      <td>2006</td>
      <td>39</td>
      <td>http://journals.aps.org/prl/abstract/10.1103/P...</td>
      <td>1DS8DjgAAAAJ</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>7328</th>
      <td>ZpG_cJwAAAAJ:zA6iFVUQeVQC</td>
      <td>Gene expression profiles at diagnosis in de no...</td>
      <td>Norman J Lacayo,Soheil Meshinchi,Paivi Kinnune...</td>
      <td>American Society of Hematology</td>
      <td>Blood</td>
      <td>Fms-like tyrosine kinase 3 (FLT3) mutations ar...</td>
      <td>104</td>
      <td>2004</td>
      <td>92</td>
      <td>http://www.bloodjournal.org/content/104/9/2646...</td>
      <td>ZpG_cJwAAAAJ</td>
    </tr>
    <tr>
      <th>7329</th>
      <td>ZpG_cJwAAAAJ:zaHkCSmj5XkC</td>
      <td>Bradley Efron</td>
      <td>Robert Tibshirani</td>
      <td>NULL</td>
      <td>NULL</td>
      <td>The purpose of model selection algorithms such...</td>
      <td>NULL</td>
      <td>2002</td>
      <td>-99</td>
      <td>https://sites.stanford.edu/statistics/sites/de...</td>
      <td>ZpG_cJwAAAAJ</td>
    </tr>
    <tr>
      <th>7330</th>
      <td>ZpG_cJwAAAAJ:zCSUwVk65WsC</td>
      <td>28 pamr. to. excel</td>
      <td>Trevor Hastie,Robert Tibshirani,Balasubramania...</td>
      <td>NULL</td>
      <td>Package ‘pamr’</td>
      <td>Arguments data A data object, of the same form...</td>
      <td>NULL</td>
      <td>2015</td>
      <td>-99</td>
      <td>http://mysql.orst.edu/pub/cran/web/packages/pa...</td>
      <td>ZpG_cJwAAAAJ</td>
    </tr>
    <tr>
      <th>7331</th>
      <td>ZpG_cJwAAAAJ:zdjWy_NXXwUC</td>
      <td>Copy Number Determination: Materials and Methods</td>
      <td>Yulei Wang,Chih Long Liu,John D Storey,Robert ...</td>
      <td>NULL</td>
      <td>NULL</td>
      <td>Total RNA was prepared from mid-log phase cult...</td>
      <td>NULL</td>
      <td>-99</td>
      <td>-99</td>
      <td>http://genome-www.stanford.edu/turnover/tmandm...</td>
      <td>ZpG_cJwAAAAJ</td>
    </tr>
    <tr>
      <th>7332</th>
      <td>ZpG_cJwAAAAJ:zdX0sdgBH_kC</td>
      <td>The samr Package</td>
      <td>R Tibshirani,G Chu,T Hastie,Balasubramanian Na...</td>
      <td>NULL</td>
      <td>NULL</td>
      <td>Results A matrix with columns: number of genes...</td>
      <td>NULL</td>
      <td>2007</td>
      <td>3</td>
      <td>http://download.nextag.com/cran/web/packages/s...</td>
      <td>ZpG_cJwAAAAJ</td>
    </tr>
    <tr>
      <th>7333</th>
      <td>ZpG_cJwAAAAJ:ZeXyd9-uunAC</td>
      <td>On the “degrees of freedom” of the lasso</td>
      <td>Hui Zou,Trevor Hastie,Robert Tibshirani</td>
      <td>Institute of Mathematical Statistics</td>
      <td>The Annals of Statistics</td>
      <td>We study the effective degrees of freedom of t...</td>
      <td>35</td>
      <td>1970</td>
      <td>555</td>
      <td>http://projecteuclid.org/euclid.aos/1194461726</td>
      <td>ZpG_cJwAAAAJ</td>
    </tr>
    <tr>
      <th>7334</th>
      <td>ZpG_cJwAAAAJ:ZfRJV9d4-WMC</td>
      <td>pamr: Pam: prediction analysis for microarrays</td>
      <td>T Hastie,R Tibshirani,Balasubramanian Narasimh...</td>
      <td>NULL</td>
      <td>R package</td>
      <td>NULL</td>
      <td>1</td>
      <td>1970</td>
      <td>42</td>
      <td>http://scholar.google.com/scholar?cluster=1333...</td>
      <td>ZpG_cJwAAAAJ</td>
    </tr>
    <tr>
      <th>7335</th>
      <td>ZpG_cJwAAAAJ:zGdJYJv2LkUC</td>
      <td>BE PRQTEQTTED BY QOPYMGHT LAW (TITLE 17, U.-S....</td>
      <td>B Efron,R Tibshirani</td>
      <td>NULL</td>
      <td>J AM STAT ASSOC</td>
      <td>NULL</td>
      <td>92</td>
      <td>1997</td>
      <td>-99</td>
      <td>http://scholar.google.com/scholar?cluster=9042...</td>
      <td>ZpG_cJwAAAAJ</td>
    </tr>
    <tr>
      <th>7336</th>
      <td>ZpG_cJwAAAAJ:zGWyAL6qfKUC</td>
      <td>Tumorigenesis and Neoplastic Progression-Oncog...</td>
      <td>Norman L Lehman,Rob Tibshirani,Jerry Y Hsu,Yas...</td>
      <td>[Hagerstown, Md., etc.] American Association o...</td>
      <td>American Journal of Pathology</td>
      <td>NULL</td>
      <td>170</td>
      <td>1970</td>
      <td>-99</td>
      <td>http://scholar.google.com/scholar?cluster=1728...</td>
      <td>ZpG_cJwAAAAJ</td>
    </tr>
    <tr>
      <th>7337</th>
      <td>ZpG_cJwAAAAJ:ZHo1McVdvXMC</td>
      <td>Early detection of breast cancer based on gene...</td>
      <td>Praveen Sharma,Narinder S Sahni,Robert Tibshir...</td>
      <td>BioMed Central</td>
      <td>Breast Cancer Research</td>
      <td>Methods Using macroarrays and nearest-shrunken...</td>
      <td>7</td>
      <td>2005</td>
      <td>123</td>
      <td>http://breast-cancer-research.biomedcentral.co...</td>
      <td>ZpG_cJwAAAAJ</td>
    </tr>
    <tr>
      <th>7338</th>
      <td>ZpG_cJwAAAAJ:ziOE8S1-AIUC</td>
      <td>18 pamr. plotstrata</td>
      <td>Trevor Hastie,Robert Tibshirani,Balasubramania...</td>
      <td>NULL</td>
      <td>khan Khan microarray data</td>
      <td>18 pamr. plotstrata Details pamr. plotfdr plot...</td>
      <td>NULL</td>
      <td>2010</td>
      <td>-99</td>
      <td>http://bioconductor.uib.no/2.7/bioc/manuals/pa...</td>
      <td>ZpG_cJwAAAAJ</td>
    </tr>
    <tr>
      <th>7339</th>
      <td>ZpG_cJwAAAAJ:zLWjf1WUPmwC</td>
      <td>Complementary hierarchical clustering</td>
      <td>Gen Nowak,Robert Tibshirani</td>
      <td>Oxford University Press</td>
      <td>Biostatistics</td>
      <td>When applying hierarchical clustering algorith...</td>
      <td>9</td>
      <td>2008</td>
      <td>24</td>
      <td>http://biostatistics.oxfordjournals.org/conten...</td>
      <td>ZpG_cJwAAAAJ</td>
    </tr>
    <tr>
      <th>7340</th>
      <td>ZpG_cJwAAAAJ:Zph67rFs4hoC</td>
      <td>Discriminant analysis by Gaussian mixtures</td>
      <td>Trevor Hastie,Robert Tibshirani</td>
      <td>Blackwell Publishers</td>
      <td>Journal of the Royal Statistical Society. Seri...</td>
      <td>Fisher-Rao linear discriminant analysis (LDA) ...</td>
      <td>NULL</td>
      <td>1996</td>
      <td>662</td>
      <td>http://www.jstor.org/stable/2346171</td>
      <td>ZpG_cJwAAAAJ</td>
    </tr>
    <tr>
      <th>7341</th>
      <td>ZpG_cJwAAAAJ:ZuybSZzF8UAC</td>
      <td>Discovery of molecular subtypes in leiomyosarc...</td>
      <td>Andrew H Beck,Cheng-Han Lee,Daniela M Witten,B...</td>
      <td>Nature Publishing Group</td>
      <td>Oncogene</td>
      <td>Leiomyosarcoma (LMS) is a soft tissue tumor wi...</td>
      <td>29</td>
      <td>2010</td>
      <td>63</td>
      <td>http://www.nature.com/onc/journal/v29/n6/abs/o...</td>
      <td>ZpG_cJwAAAAJ</td>
    </tr>
    <tr>
      <th>7342</th>
      <td>ZpG_cJwAAAAJ:zYLM7Y9cAGgC</td>
      <td>Additive logistic regression: a statistical vi...</td>
      <td>Jerome Friedman,Trevor Hastie,Robert Tibshirani</td>
      <td>Institute of Mathematical Statistics</td>
      <td>The annals of statistics</td>
      <td>Boosting is one of the most important recent d...</td>
      <td>28</td>
      <td>1970</td>
      <td>5082</td>
      <td>http://projecteuclid.org/euclid.aos/1016218223</td>
      <td>ZpG_cJwAAAAJ</td>
    </tr>
    <tr>
      <th>7343</th>
      <td>ZpG_cJwAAAAJ:ZzlSgRqYykMC</td>
      <td>The lasso: some novel algorithms and applications</td>
      <td>Robert Tibshirani,Gen Nowak Hoefling,Pei Wang,...</td>
      <td>NULL</td>
      <td>NULL</td>
      <td>Page 1. 1 The lasso: some novel algorithms and...</td>
      <td>NULL</td>
      <td>-99</td>
      <td>-99</td>
      <td>http://www-old.newton.ac.uk/webseminars/pg+ws/...</td>
      <td>ZpG_cJwAAAAJ</td>
    </tr>
    <tr>
      <th>7344</th>
      <td>ZpG_cJwAAAAJ:z_wVstp3MssC</td>
      <td>impute: impute: Imputation for microarray data</td>
      <td>Trevor Hastie,Robert Tibshirani,Balasubramania...</td>
      <td>R package version</td>
      <td>NULL</td>
      <td>NULL</td>
      <td>1</td>
      <td>1970</td>
      <td>57</td>
      <td>http://scholar.google.com/scholar?cluster=1964...</td>
      <td>ZpG_cJwAAAAJ</td>
    </tr>
    <tr>
      <th>7345</th>
      <td>ZpG_cJwAAAAJ:_5tno0g5mFcC</td>
      <td>Stagewise algorithms and lasso-type problems</td>
      <td>Trevor Hastie,Jonathan Taylor,Robert Tibshiran...</td>
      <td>NULL</td>
      <td>Electronic journal of statistics</td>
      <td>NULL</td>
      <td>NULL</td>
      <td>1970</td>
      <td>1</td>
      <td>http://scholar.google.com/scholar?cluster=1561...</td>
      <td>ZpG_cJwAAAAJ</td>
    </tr>
    <tr>
      <th>7346</th>
      <td>ZpG_cJwAAAAJ:_AkkBXT-jcoC</td>
      <td>Statistical Learning</td>
      <td>Trevor Hastie,Robert Tibshirani</td>
      <td>NULL</td>
      <td>Learning</td>
      <td>Learning from its mistakes According to David ...</td>
      <td>2</td>
      <td>1970</td>
      <td>46</td>
      <td>https://lagunita.stanford.edu/c4x/HumanitiesSc...</td>
      <td>ZpG_cJwAAAAJ</td>
    </tr>
    <tr>
      <th>7347</th>
      <td>ZpG_cJwAAAAJ:_axFR9aDTf0C</td>
      <td>CC chemokine receptor 1 expression in human he...</td>
      <td>Matthew W Anderson,Shuchun Zhao,Weiyun Z Ai,Ro...</td>
      <td>The Oxford University Press</td>
      <td>American journal of clinical pathology</td>
      <td>Chemokine receptor 1 (CCR1) is a G protein–cou...</td>
      <td>133</td>
      <td>2010</td>
      <td>9</td>
      <td>http://ajcp.oxfordjournals.org/content/133/3/4...</td>
      <td>ZpG_cJwAAAAJ</td>
    </tr>
    <tr>
      <th>7348</th>
      <td>ZpG_cJwAAAAJ:_B80troHkn4C</td>
      <td>Extensions of sparse canonical correlation ana...</td>
      <td>Daniela M Witten,Robert J Tibshirani</td>
      <td>NULL</td>
      <td>Statistical applications in genetics and molec...</td>
      <td>In recent work, several authors have introduce...</td>
      <td>8</td>
      <td>2009</td>
      <td>150</td>
      <td>http://www.degruyter.com/view/j/sagmb.2009.8.1...</td>
      <td>ZpG_cJwAAAAJ</td>
    </tr>
    <tr>
      <th>7349</th>
      <td>ZpG_cJwAAAAJ:_FM0Bhl9EiAC</td>
      <td>Prognostic Gene-Expression Signatures in Adult...</td>
      <td>Lars Bullinger,Eric Bair,Raphael Kranz,Konstan...</td>
      <td>American Society of Hematology</td>
      <td>Blood</td>
      <td>Acute myeloid leukemia (AML) encompasses a lar...</td>
      <td>106</td>
      <td>2005</td>
      <td>-99</td>
      <td>http://www.bloodjournal.org/content/106/11/756...</td>
      <td>ZpG_cJwAAAAJ</td>
    </tr>
    <tr>
      <th>7350</th>
      <td>ZpG_cJwAAAAJ:_FxGoFyzp5QC</td>
      <td>Varying-coefficient models</td>
      <td>Trevor Hastie,Robert Tibshirani</td>
      <td>Blackwell Publishers</td>
      <td>Journal of the Royal Statistical Society. Seri...</td>
      <td>We explore a class of regression and generaliz...</td>
      <td>NULL</td>
      <td>1993</td>
      <td>1513</td>
      <td>http://www.jstor.org/stable/2345993</td>
      <td>ZpG_cJwAAAAJ</td>
    </tr>
    <tr>
      <th>7351</th>
      <td>ZpG_cJwAAAAJ:_kc_bZDykSQC</td>
      <td>Precision and functional specificity in mRNA d...</td>
      <td>Yulei Wang,Chih Long Liu,John D Storey,Robert ...</td>
      <td>National Acad Sciences</td>
      <td>Proceedings of the National Academy of Sciences</td>
      <td>Posttranscriptional processing of mRNA is an i...</td>
      <td>99</td>
      <td>2002</td>
      <td>645</td>
      <td>http://www.pnas.org/content/99/9/5860.short</td>
      <td>ZpG_cJwAAAAJ</td>
    </tr>
    <tr>
      <th>7352</th>
      <td>ZpG_cJwAAAAJ:_OXeSy2IsFwC</td>
      <td>Class prediction by nearest shrunken</td>
      <td>Robert TibShirani,Trevor HaStie,BalaSubramania...</td>
      <td>NULL</td>
      <td>NULL</td>
      <td>NULL</td>
      <td>NULL</td>
      <td>2002</td>
      <td>-99</td>
      <td>http://scholar.google.com/scholar?cluster=3463...</td>
      <td>ZpG_cJwAAAAJ</td>
    </tr>
    <tr>
      <th>7353</th>
      <td>ZpG_cJwAAAAJ:_Qo2XoVZTnwC</td>
      <td>A comparison of some error estimates for neura...</td>
      <td>Robert Tibshirani</td>
      <td>NULL</td>
      <td>Neural Computation</td>
      <td>We discuss a number of methods for estimating ...</td>
      <td>8</td>
      <td>1996</td>
      <td>252</td>
      <td>http://www.mitpressjournals.org/doi/abs/10.116...</td>
      <td>ZpG_cJwAAAAJ</td>
    </tr>
    <tr>
      <th>7354</th>
      <td>ZpG_cJwAAAAJ:_Re3VWB3Y0AC</td>
      <td>Are those other drivers really going faster?</td>
      <td>Donald A Redelmeier,Robert J Tibshirani</td>
      <td>Taylor &amp; Francis Group</td>
      <td>Chance</td>
      <td>Motor-vehicle travel is a mixed blessing for m...</td>
      <td>13</td>
      <td>2000</td>
      <td>19</td>
      <td>http://www.tandfonline.com/doi/pdf/10.1080/093...</td>
      <td>ZpG_cJwAAAAJ</td>
    </tr>
    <tr>
      <th>7355</th>
      <td>ZpG_cJwAAAAJ:_xSYboBqXhAC</td>
      <td>Spinal deformity after multiple-level cervical...</td>
      <td>Deborah F Bell,Janet L Walker,Gary O'Connor,Ro...</td>
      <td>LWW</td>
      <td>Spine</td>
      <td>Considerable controversy exists in the orthope...</td>
      <td>19</td>
      <td>1994</td>
      <td>81</td>
      <td>http://journals.lww.com/spinejournal/abstract/...</td>
      <td>ZpG_cJwAAAAJ</td>
    </tr>
    <tr>
      <th>7356</th>
      <td>ZpG_cJwAAAAJ:_Ybze24A_UAC</td>
      <td>Is using a car phone like driving drunk?</td>
      <td>Donald A Redelmeier,Robert J Tibshirani</td>
      <td>Taylor &amp; Francis Group</td>
      <td>Chance</td>
      <td>Background We were motivated to do this resear...</td>
      <td>10</td>
      <td>1997</td>
      <td>13</td>
      <td>http://www.tandfonline.com/doi/pdf/10.1080/093...</td>
      <td>ZpG_cJwAAAAJ</td>
    </tr>
    <tr>
      <th>7357</th>
      <td>ZpG_cJwAAAAJ:__bU50VfleQC</td>
      <td>A sparse-group lasso</td>
      <td>Noah Simon,Jerome Friedman,Trevor Hastie,Rober...</td>
      <td>Taylor &amp; Francis Group</td>
      <td>Journal of Computational and Graphical Statistics</td>
      <td>For high-dimensional supervised learning probl...</td>
      <td>22</td>
      <td>2013</td>
      <td>219</td>
      <td>http://www.tandfonline.com/doi/abs/10.1080/106...</td>
      <td>ZpG_cJwAAAAJ</td>
    </tr>
  </tbody>
</table>
<p>7358 rows × 11 columns</p>
</div>




```python
query_list,field_names = mysql_setup.query_with_fetchmany("SELECT Pub_Journal FROM Publishing_Detail")
Pub_Journal = mysql_setup.make_frame(query_list,field_names)
```


```python
Pub_Journal
```




<div>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Pub_Journal</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>NULL</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Physical Review D</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Physical Review D</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Physical review letters</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Physical review letters</td>
    </tr>
    <tr>
      <th>5</th>
      <td>The European Physical Journal C</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Physics Letters B</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Physical Review D</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Physical review letters</td>
    </tr>
    <tr>
      <th>9</th>
      <td>The European Physical Journal C</td>
    </tr>
    <tr>
      <th>10</th>
      <td>Journal of High Energy Physics</td>
    </tr>
    <tr>
      <th>11</th>
      <td>Physics Letters B</td>
    </tr>
    <tr>
      <th>12</th>
      <td>Physical Review D</td>
    </tr>
    <tr>
      <th>13</th>
      <td>Journal of High Energy Physics</td>
    </tr>
    <tr>
      <th>14</th>
      <td>Journal of High Energy Physics</td>
    </tr>
    <tr>
      <th>15</th>
      <td>The European Physical Journal C</td>
    </tr>
    <tr>
      <th>16</th>
      <td>Physical Review Letters</td>
    </tr>
    <tr>
      <th>17</th>
      <td>Physics Letters B</td>
    </tr>
    <tr>
      <th>18</th>
      <td>The European Physical Journal C</td>
    </tr>
    <tr>
      <th>19</th>
      <td>Journal of High Energy Physics</td>
    </tr>
    <tr>
      <th>20</th>
      <td>Physics letters B</td>
    </tr>
    <tr>
      <th>21</th>
      <td>NULL</td>
    </tr>
    <tr>
      <th>22</th>
      <td>Physical review letters</td>
    </tr>
    <tr>
      <th>23</th>
      <td>NULL</td>
    </tr>
    <tr>
      <th>24</th>
      <td>Journal of High Energy Physics</td>
    </tr>
    <tr>
      <th>25</th>
      <td>NULL</td>
    </tr>
    <tr>
      <th>26</th>
      <td>Physical Review D</td>
    </tr>
    <tr>
      <th>27</th>
      <td>The European Physical Journal C</td>
    </tr>
    <tr>
      <th>28</th>
      <td>Physical review letters</td>
    </tr>
    <tr>
      <th>29</th>
      <td>Physical review letters</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
    </tr>
    <tr>
      <th>7328</th>
      <td>Blood</td>
    </tr>
    <tr>
      <th>7329</th>
      <td>NULL</td>
    </tr>
    <tr>
      <th>7330</th>
      <td>Package ‘pamr’</td>
    </tr>
    <tr>
      <th>7331</th>
      <td>NULL</td>
    </tr>
    <tr>
      <th>7332</th>
      <td>NULL</td>
    </tr>
    <tr>
      <th>7333</th>
      <td>The Annals of Statistics</td>
    </tr>
    <tr>
      <th>7334</th>
      <td>R package</td>
    </tr>
    <tr>
      <th>7335</th>
      <td>J AM STAT ASSOC</td>
    </tr>
    <tr>
      <th>7336</th>
      <td>American Journal of Pathology</td>
    </tr>
    <tr>
      <th>7337</th>
      <td>Breast Cancer Research</td>
    </tr>
    <tr>
      <th>7338</th>
      <td>khan Khan microarray data</td>
    </tr>
    <tr>
      <th>7339</th>
      <td>Biostatistics</td>
    </tr>
    <tr>
      <th>7340</th>
      <td>Journal of the Royal Statistical Society. Seri...</td>
    </tr>
    <tr>
      <th>7341</th>
      <td>Oncogene</td>
    </tr>
    <tr>
      <th>7342</th>
      <td>The annals of statistics</td>
    </tr>
    <tr>
      <th>7343</th>
      <td>NULL</td>
    </tr>
    <tr>
      <th>7344</th>
      <td>NULL</td>
    </tr>
    <tr>
      <th>7345</th>
      <td>Electronic journal of statistics</td>
    </tr>
    <tr>
      <th>7346</th>
      <td>Learning</td>
    </tr>
    <tr>
      <th>7347</th>
      <td>American journal of clinical pathology</td>
    </tr>
    <tr>
      <th>7348</th>
      <td>Statistical applications in genetics and molec...</td>
    </tr>
    <tr>
      <th>7349</th>
      <td>Blood</td>
    </tr>
    <tr>
      <th>7350</th>
      <td>Journal of the Royal Statistical Society. Seri...</td>
    </tr>
    <tr>
      <th>7351</th>
      <td>Proceedings of the National Academy of Sciences</td>
    </tr>
    <tr>
      <th>7352</th>
      <td>NULL</td>
    </tr>
    <tr>
      <th>7353</th>
      <td>Neural Computation</td>
    </tr>
    <tr>
      <th>7354</th>
      <td>Chance</td>
    </tr>
    <tr>
      <th>7355</th>
      <td>Spine</td>
    </tr>
    <tr>
      <th>7356</th>
      <td>Chance</td>
    </tr>
    <tr>
      <th>7357</th>
      <td>Journal of Computational and Graphical Statistics</td>
    </tr>
  </tbody>
</table>
<p>7358 rows × 1 columns</p>
</div>




```python
type(Pub_Journal)
```




    pandas.core.frame.DataFrame




```python
len(Pub_Journal.Pub_Journal.unique())
```




    1739




```python
import scholarly_edit
x = scholarly_edit.search_journal('Blood')
```


    ---------------------------------------------------------------------------

    ConnectionError                           Traceback (most recent call last)

    <ipython-input-11-9c3566b8b9bb> in <module>()
          1 import scholarly_edit
    ----> 2 x = scholarly_edit.search_journal('Blood')
    

    c:\Users\Raunak Mundada\Dropbox\NLP_Project\scholarly_edit.pyc in search_journal(keyword)
        376 
        377 def search_journal(keyword):
    --> 378     soup = _get_soup(_JOURNALSEARCH.format(requests.utils.quote(keyword)))
        379     return _search_journal_soup(soup)
        380 
    

    c:\Users\Raunak Mundada\Dropbox\NLP_Project\scholarly_edit.pyc in _get_soup(pagerequest)
         88 def _get_soup(pagerequest):
         89     """Return the BeautifulSoup for a page on scholar.google.com"""
    ---> 90     html = _get_page(pagerequest)
         91     return BeautifulSoup(html, 'html.parser')
         92 
    

    c:\Users\Raunak Mundada\Dropbox\NLP_Project\scholarly_edit.pyc in _get_page(pagerequest)
         53     # Note that we include a sleep to avoid overloading the scholar server
         54     time.sleep(20+random.uniform(0, 5))
    ---> 55     resp_url = _SESSION.get(_SCHOLARHOST+pagerequest, headers=_HEADERS, cookies=_COOKIES)
         56     #print (_SCHOLARHOST+pagerequest)
         57     #print (resp_url.status_code)
    

    C:\Users\Raunak Mundada\Anaconda2\lib\site-packages\requests\sessions.pyc in get(self, url, **kwargs)
        485 
        486         kwargs.setdefault('allow_redirects', True)
    --> 487         return self.request('GET', url, **kwargs)
        488 
        489     def options(self, url, **kwargs):
    

    C:\Users\Raunak Mundada\Anaconda2\lib\site-packages\requests\sessions.pyc in request(self, method, url, params, data, headers, cookies, files, auth, timeout, allow_redirects, proxies, hooks, stream, verify, cert, json)
        473         }
        474         send_kwargs.update(settings)
    --> 475         resp = self.send(prep, **send_kwargs)
        476 
        477         return resp
    

    C:\Users\Raunak Mundada\Anaconda2\lib\site-packages\requests\sessions.pyc in send(self, request, **kwargs)
        583 
        584         # Send the request
    --> 585         r = adapter.send(request, **kwargs)
        586 
        587         # Total elapsed time of the request (approximately)
    

    C:\Users\Raunak Mundada\Anaconda2\lib\site-packages\requests\adapters.pyc in send(self, request, stream, timeout, verify, cert, proxies)
        465                 raise ProxyError(e, request=request)
        466 
    --> 467             raise ConnectionError(e, request=request)
        468 
        469         except ClosedPoolError as e:
    

    ConnectionError: HTTPSConnectionPool(host='scholar.google.comcitations', port=443): Max retries exceeded with url: /?hl=en&view_op=search_venues&vq=Blood (Caused by NewConnectionError('<requests.packages.urllib3.connection.VerifiedHTTPSConnection object at 0x000000000D32A828>: Failed to establish a new connection: [Errno 11001] getaddrinfo failed',))



```python
sns.set_context({"figure.figsize": (24, 10)})
sns.set_style("whitegrid")
Author = Author.sort_values('Author_Cited_By')
labels = Author.Author_Name
g = sns.barplot(x = Author.Author_Name, y = Author.Author_Cited_By, data = Author)
g.set_xticklabels(labels,rotation = 90)
plt.title("Total Citations - by Author")
plt.xlabel('Author')
plt.ylabel('Total Citations')
g.axes.grid('off')
sns.set(font_scale=2)
```


![png](output_11_0.png)



```python
df = pd.melt(Author,id_vars = ['Author_Name'],value_vars = ['Author_hIndex','Author_i10Index'])
labels = df.Author_Name
sns.set_context({"figure.figsize": (24, 10)})
sns.set_style("whitegrid")
g = sns.barplot(x = 'Author_Name',y='value',hue = 'variable',data = df)
g.set_xticklabels(labels,rotation = 90)
plt.title("Citation Indices")
plt.xlabel('Author')
plt.ylabel('Citations Index')
g.axes.grid('off')
sns.set(font_scale=2)
```


![png](output_12_0.png)



```python
df = pd.melt(Author,id_vars = ['Author_Name'],value_vars = ['Author_hIndex_recent','Author_i10Index_recent'])
labels = df.Author_Name
sns.set_context({"figure.figsize": (24, 10)})
sns.set_style("whitegrid")
g = sns.barplot(x = 'Author_Name',y='value',hue = 'variable',data = df)
g.set_xticklabels(labels,rotation = 90)
plt.title("Citation Indices")
plt.xlabel('Author')
plt.ylabel('Citations Index')
g.axes.grid('off')
sns.set(font_scale=2)
```


![png](output_13_0.png)



```python
type(Author.Author_Interests[0])
```




    unicode




```python
Author['Author_Interests'] = Author['Author_Interests'].astype('str')
```


```python
keyword = 'machine learning'
df_ml = pd.DataFrame()
for index,row in Author.iterrows():
    a_interests  = (row['Author_Interests'])
    if keyword in a_interests.lower():
        df_ml =  df_ml.append(row,ignore_index=True)
```


```python
df_ml
```




<div>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Author_Affiliation</th>
      <th>Author_Cited_By</th>
      <th>Author_Email</th>
      <th>Author_Id</th>
      <th>Author_Interests</th>
      <th>Author_Name</th>
      <th>Author_hIndex</th>
      <th>Author_hIndex_recent</th>
      <th>Author_i10Index</th>
      <th>Author_i10Index_recent</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Google, Inc. / ETH Zurich</td>
      <td>837.0</td>
      <td>@inf.ethz.ch</td>
      <td>6yx_xmcAAAAJ</td>
      <td>Bayesian inference,Machine learning,Computatio...</td>
      <td>Kay H. Brodersen</td>
      <td>14.0</td>
      <td>14.0</td>
      <td>17.0</td>
      <td>17.0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Data61, Canberra</td>
      <td>2539.0</td>
      <td>@anu.edu.au</td>
      <td>ofMZr0IAAAAJ</td>
      <td>Machine Learning,Bioinformatics,Computational ...</td>
      <td>Cheng Soon Ong</td>
      <td>21.0</td>
      <td>18.0</td>
      <td>30.0</td>
      <td>26.0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>Professor of Computer Science, Columbia Univer...</td>
      <td>17039.0</td>
      <td>@cs.columbia.edu</td>
      <td>DxoenfgAAAAJ</td>
      <td>Computational Linguistics,Natural Language Pro...</td>
      <td>Michael Collins</td>
      <td>47.0</td>
      <td>40.0</td>
      <td>70.0</td>
      <td>66.0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>Duke University, MIT</td>
      <td>22477.0</td>
      <td>@stat.duke.edu</td>
      <td>R94cBVgAAAAJ</td>
      <td>machine learning,computational biology,stochas...</td>
      <td>Sayan Mukherjee</td>
      <td>39.0</td>
      <td>33.0</td>
      <td>79.0</td>
      <td>68.0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>Google Research, NY</td>
      <td>28008.0</td>
      <td>@google.com</td>
      <td>U_IVY50AAAAJ</td>
      <td>Machine Learning,Datamining</td>
      <td>Corinna Cortes</td>
      <td>39.0</td>
      <td>31.0</td>
      <td>70.0</td>
      <td>57.0</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Facebook</td>
      <td>28073.0</td>
      <td>@fb.com</td>
      <td>lMkTx0EAAAAJ</td>
      <td>Artificial Intelligence,Machine Learning,Bioin...</td>
      <td>Jason Weston</td>
      <td>63.0</td>
      <td>51.0</td>
      <td>125.0</td>
      <td>116.0</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Director of AI Research at Facebook &amp; Silver P...</td>
      <td>35315.0</td>
      <td>@cs.nyu.edu</td>
      <td>WLN3QrAAAAAJ</td>
      <td>AI,machine learning,computer vision,robotics,i...</td>
      <td>Yann LeCun</td>
      <td>81.0</td>
      <td>64.0</td>
      <td>202.0</td>
      <td>155.0</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Professor of Computer Science, Stanford Univer...</td>
      <td>50410.0</td>
      <td>@cs.stanford.edu</td>
      <td>5Iqe53IAAAAJ</td>
      <td>machine learning,computational biology,compute...</td>
      <td>Daphne Koller</td>
      <td>112.0</td>
      <td>77.0</td>
      <td>269.0</td>
      <td>238.0</td>
    </tr>
    <tr>
      <th>8</th>
      <td>Research Associate, Harvard University</td>
      <td>56022.0</td>
      <td>@physics.harvard.edu</td>
      <td>P6krKIkAAAAJ</td>
      <td>Data science,high energy physics,machine learning</td>
      <td>David Lopez Mateos</td>
      <td>101.0</td>
      <td>97.0</td>
      <td>291.0</td>
      <td>279.0</td>
    </tr>
    <tr>
      <th>9</th>
      <td>Queen Mary University of London</td>
      <td>60944.0</td>
      <td>@qmul.ac.uk</td>
      <td>1DS8DjgAAAAJ</td>
      <td>Particle Physics,Higgs bosons,Machine learning...</td>
      <td>Jonathan Hays</td>
      <td>115.0</td>
      <td>108.0</td>
      <td>572.0</td>
      <td>520.0</td>
    </tr>
    <tr>
      <th>10</th>
      <td>Professor of Electrical and Computer Engineeri...</td>
      <td>88035.0</td>
      <td>@egr.msu.edu</td>
      <td>paTAXiIAAAAJ</td>
      <td>Optimization,Evolutionary Computation,Multi-ob...</td>
      <td>Kalyanmoy Deb</td>
      <td>97.0</td>
      <td>70.0</td>
      <td>351.0</td>
      <td>272.0</td>
    </tr>
    <tr>
      <th>11</th>
      <td>Professor of EECS and Professor of Statistics,...</td>
      <td>99956.0</td>
      <td>@cs.berkeley.edu</td>
      <td>yxUduqMAAAAJ</td>
      <td>machine learning,statistics,computational biol...</td>
      <td>Michael I. Jordan</td>
      <td>129.0</td>
      <td>88.0</td>
      <td>397.0</td>
      <td>334.0</td>
    </tr>
    <tr>
      <th>12</th>
      <td>Emeritus Professor of Computer Science, Univer...</td>
      <td>133698.0</td>
      <td>@cs.toronto.edu</td>
      <td>JicYPdAAAAAJ</td>
      <td>machine learning,neural networks,artificial in...</td>
      <td>Geoffrey Hinton</td>
      <td>120.0</td>
      <td>87.0</td>
      <td>288.0</td>
      <td>205.0</td>
    </tr>
    <tr>
      <th>13</th>
      <td>Professor of Columbia, Fellow of NEC Labs Amer...</td>
      <td>168020.0</td>
      <td>@nec-labs.com</td>
      <td>vtegaJgAAAAJ</td>
      <td>machine learning,statistics,computer science</td>
      <td>vapnik</td>
      <td>108.0</td>
      <td>73.0</td>
      <td>372.0</td>
      <td>278.0</td>
    </tr>
    <tr>
      <th>14</th>
      <td>Professor of Health Research and Policy, and S...</td>
      <td>222620.0</td>
      <td>@stanford.edu</td>
      <td>ZpG_cJwAAAAJ</td>
      <td>Statistics,Applied Statistics,Statistical lear...</td>
      <td>Robert Tibshirani</td>
      <td>130.0</td>
      <td>94.0</td>
      <td>336.0</td>
      <td>283.0</td>
    </tr>
  </tbody>
</table>
</div>




```python
df_ml['Author_Interests'] = df_ml['Author_Interests'].astype(str)
a_interests = df_ml['Author_Interests'].tolist()
type(a_interests)
a_interests = " ".join(str(i) for i in a_interests if not i.isdigit() and  len(i)>3)
a_interests
```




    'Bayesian inference,Machine learning,Computational modelling,Neuroimaging,Dynamic causal modelling Machine Learning,Bioinformatics,Computational Biology Computational Linguistics,Natural Language Processing,Machine Learning,Artificial Intelligence machine learning,computational biology,stochastic topology,stochastic geometry Machine Learning,Datamining Artificial Intelligence,Machine Learning,Bioinformatics,Vision,Natural Language Processing AI,machine learning,computer vision,robotics,image compression machine learning,computational biology,computer vision,artificial intelligence Data science,high energy physics,machine learning Particle Physics,Higgs bosons,Machine learning,Big data,Proteomics Optimization,Evolutionary Computation,Multi-objective optimization,Optimal design,Machine Learning machine learning,statistics,computational biology,artificial intelligence,optimization machine learning,neural networks,artificial intelligence,cognitive science,computer science machine learning,statistics,computer science Statistics,Applied Statistics,Statistical learning,machine learning,high dimensional data'




```python
import random
import matplotlib as mpl
import matplotlib.pyplot as plt
import os
from PIL import Image
from os import path
from nltk.corpus import stopwords
from scipy.misc import imread
from sklearn.feature_extraction.stop_words import ENGLISH_STOP_WORDS
from wordcloud import WordCloud, STOPWORDS

limit = 1000
infosize = 12

title = 'Most frequent words Job Title'
chartinfo = 'SF Salaries Job Titles'
footer = 'The {} most frequent words, excluding English stopwords.\n{}'.format(limit, chartinfo)
#font = '/usr/share/fonts/truetype/ubuntu-font-family/Ubuntu-B.ttf'
fontcolor='#fafafa'
bgcolor = '#000000'
english_stopwords = set(stopwords.words('english')) | STOPWORDS | ENGLISH_STOP_WORDS
```


```python
d = os.getcwd()
ml_mask = np.array(Image.open(path.join(d, "machine-learning-head-964x670-482x335.jpg")))
wordcloud = WordCloud(
    max_words=limit,
    stopwords=english_stopwords,
    mask = ml_mask,
    background_color = "white",
).generate(a_interests)

```


```python
def grey_color(word, font_size, position, orientation, random_state=None, **kwargs):
    return 'hsl(0, 0%%, %d%%)' % random.randint(50, 100)

fig = plt.figure()
fig.set_figwidth(10)
fig.set_figheight(14)

plt.imshow(wordcloud.recolor(random_state=3))
plt.title(title, color=fontcolor, size=30, y=1.01)
plt.axis('off')
plt.show()

```


![png](output_21_0.png)



```python
a_id = df_ml.Author_Id.tolist()
```


```python
from __future__ import print_function
import mysql.connector
from mysql.connector import errorcode
from mysql.connector import Error
import pandas as pd

DB_NAME = 'NLP_Project'
in_p=', '.join(list(map(lambda x: '%s', a_id)))
sql = ("SELECT * FROM publishing_Detail WHERE Author_Id in (%s)")
sql = sql % in_p
query_list = list()
cnx = mysql.connector.connect(user='root',password = "raunak")
cursor = cnx.cursor()
cnx.database = DB_NAME
cursor.execute(sql,a_id)
for row in iter(cursor):
        query_list.append(row)
        num_fields = len(cursor.description)
        field_names = [i[0] for i in cursor.description]
        field_names
cursor.close()
cnx.close()
```


```python
ml_Detail = mysql_setup.make_frame(query_list,field_names)
```


```python
len(ml_Detail.Author_Id.unique())
```




    14




```python
a_id
```




    [u'6yx_xmcAAAAJ',
     u'ofMZr0IAAAAJ',
     u'DxoenfgAAAAJ',
     u'R94cBVgAAAAJ',
     u'U_IVY50AAAAJ',
     u'lMkTx0EAAAAJ',
     u'WLN3QrAAAAAJ',
     u'5Iqe53IAAAAJ',
     u'P6krKIkAAAAJ',
     u'1DS8DjgAAAAJ',
     u'paTAXiIAAAAJ',
     u'yxUduqMAAAAJ',
     u'JicYPdAAAAAJ',
     u'vtegaJgAAAAJ',
     u'ZpG_cJwAAAAJ']




```python
ml_Detail.shape
```




    (6617, 11)




```python
ml_Detail = ml_Detail[ml_Detail.Pub_Journal != "NULL"]
ml_Detail.Pub_Journal = ml_Detail.Pub_Journal.astype('category')
```


```python
x = ml_Detail.groupby('Pub_Journal').agg(['count'])
x
```




<div>
<table border="1" class="dataframe">
  <thead>
    <tr>
      <th></th>
      <th>Pub_Id</th>
      <th>Pub_Title</th>
      <th>Pub_Authors</th>
      <th>Pub_Publisher</th>
      <th>Pub_Abstract</th>
      <th>Pub_Volume</th>
      <th>Pub_Year</th>
      <th>Pub_Citedby</th>
      <th>Pub_URL</th>
      <th>Author_Id</th>
    </tr>
    <tr>
      <th></th>
      <th>count</th>
      <th>count</th>
      <th>count</th>
      <th>count</th>
      <th>count</th>
      <th>count</th>
      <th>count</th>
      <th>count</th>
      <th>count</th>
      <th>count</th>
    </tr>
    <tr>
      <th>Pub_Journal</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1965.</th>
      <td>3</td>
      <td>3</td>
      <td>3</td>
      <td>3</td>
      <td>3</td>
      <td>3</td>
      <td>3</td>
      <td>3</td>
      <td>3</td>
      <td>3</td>
    </tr>
    <tr>
      <th>1966.</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>19° Colloque sur le traitement du signal et des images, FRA, 2003</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2009 UroToday International Journal</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>22nd Annual Pittsburgh Conference on Modeling and Simulation</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>23rd international conference on Machine learning, Pittsburgh</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2nd International Conference on Computational Mechanics and Simulation (ICCMS-2006), Guwahati, India</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>55 th International Astronautical Congress</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>9th Annual Symposium on Information Assurance (ASIA’14)</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>A Fast Multiobjective Evolutionary Algorithm for Finding Well-Spread Pareto-Optimal Solutions,” KanGAL Report</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>AAAI</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>AAAI Fall Symposium Series: Machine Learning in Computer Vision Raleigh, North Carolina USA</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>AAAI/IAAI</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>ACG case reports journal</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>ACM Computing Surveys (CSUR)</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>ACM SIGKDD Explorations Newsletter</th>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
    </tr>
    <tr>
      <th>ACM SIGPLAN Notices</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>ACM Trans. Computational Logic</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>ACM Transactions on Computational Logic (TOCL)</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>ACM Transactions on Graphics (TOG)</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>ACM Transactions on Programming Languages and Systems (TOPLAS)</th>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
    </tr>
    <tr>
      <th>ACM Transactions on Sensor Networks (TOSN)</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>ACM Transactions on Software Engineering and Methodology (TOSEM)</th>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
    </tr>
    <tr>
      <th>ADVANCES IN NEURAL INFORMATION PROCESSING SYSTEMS</th>
      <td>3</td>
      <td>3</td>
      <td>3</td>
      <td>3</td>
      <td>3</td>
      <td>3</td>
      <td>3</td>
      <td>3</td>
      <td>3</td>
      <td>3</td>
    </tr>
    <tr>
      <th>AFINIDAD</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>AGU Fall Meeting Abstracts</th>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
    </tr>
    <tr>
      <th>AI EDAM</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>AIAA/ASME/ASCE/AHS/ASC Structures, Structural Dynamics and Materials Conference, 31 st, Long Beach, CA</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>AIChE journal</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>AIP conference proceedings</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>arXiv preprint arXiv:1605.06275</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>arXiv preprint arXiv:1605.06443</th>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
    </tr>
    <tr>
      <th>arXiv preprint arXiv:1605.06636</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>arXiv preprint arXiv:1605.07683</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>arXiv preprint arXiv:1605.07689</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>arXiv preprint arXiv:1605.09721</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>arXiv preprint arXiv:1606.03126</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>arXiv preprint hep-ex/0307057</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>arXiv preprint hep-th/0401058</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>arXiv preprint math.ST/0510521</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>arXiv preprint math.ST/0608556</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>arXiv preprint math/0608061</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>constraints</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>et-al. Frontiers in cognitive neuroscience</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>experimental animals</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>fulfillment of Written Preliminary Exam II requirement</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>h ttp://robotics. eecs. berkeley. edu/∼ pister/SmartDust</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>keynote address, IPSN</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>khan Khan microarray data</th>
      <td>7</td>
      <td>7</td>
      <td>7</td>
      <td>7</td>
      <td>7</td>
      <td>7</td>
      <td>7</td>
      <td>7</td>
      <td>7</td>
      <td>7</td>
    </tr>
    <tr>
      <th>margin</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>memory</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>nature neuroscience</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>proceedings of EMNLP-CoNLL</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>science</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>stat</th>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
      <td>2</td>
    </tr>
    <tr>
      <th>talk slides, http://knwloon. eecs. berkeley. edu/~ boser/pdf/feedback. pdf</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>to the Eighth Annual Symposium on Biomedical Computation at Stanford (BCATS).</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>Автоматика и телемеханика</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>情報処理学会論文誌数理モデル化と応用 (TOM)</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
    </tr>
    <tr>
      <th>計測と制御</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
<p>1483 rows × 10 columns</p>
</div>




```python

```
